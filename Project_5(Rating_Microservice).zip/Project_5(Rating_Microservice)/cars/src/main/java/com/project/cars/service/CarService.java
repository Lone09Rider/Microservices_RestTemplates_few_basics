package com.project.cars.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.cars.entity.Car;
import com.project.cars.repository.CarRepository;
import java.util.List;

@Service
public class CarService {
    @Autowired
    private CarRepository carRepository;

    // method to get all cars
    public List<Car> getAllCars() {
        return carRepository.findAll();
    }

    // method to get car by id
    public Car getCarById(int id) {
        return carRepository.findById(id).get();
    }

    // method to save a car
    public Car saveCar(Car car) {
        return carRepository.save(car);
    }

    // method to delete a car
    public void deleteCar(int id) {
        carRepository.deleteById(id);
    }

    // method to get car by rating id
    public List<Car> getCarByRatingId(int id) {
        return carRepository.findByRatingId(id);
    }
}
