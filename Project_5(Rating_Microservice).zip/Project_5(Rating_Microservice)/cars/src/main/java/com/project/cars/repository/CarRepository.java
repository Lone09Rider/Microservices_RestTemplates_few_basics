package com.project.cars.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.cars.entity.Car;
import java.util.List;

public interface CarRepository extends JpaRepository<Car, Integer> {
    public List<Car> findByRatingId(int id);
}
