package com.project.ratings.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class Mechanic {
    private int mechId;
    private String mechName;
    private int ratingId;
}
