package com.project.ratings.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.ratings.entity.Rating;

public interface RatingRepository extends JpaRepository<Rating, Integer> {
    
}
