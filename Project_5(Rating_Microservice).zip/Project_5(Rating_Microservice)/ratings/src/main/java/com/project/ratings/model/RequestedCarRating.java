package com.project.ratings.model;

import com.project.ratings.entity.Rating;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RequestedCarRating {
    private Rating rating;
    private List<Car> cars;
}
