package com.project.ratings.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.project.ratings.entity.Rating;
import com.project.ratings.model.CarMech;
import com.project.ratings.model.RequestedCarRating;
import com.project.ratings.model.RequestedMechanicRating;
import com.project.ratings.repository.RatingRepository;

@RestController
@RequestMapping("/ratings")
public class RatingController {
    @Autowired
    private RatingRepository repository;
    @Autowired
    private RestTemplate restTemplate;

    @GetMapping("/all")
    // method to get all ratings
    public List<Rating> getRatings() {
        return repository.findAll();
    }

    @GetMapping("/car/rating/{id}")
    // method to get rating by id with resttemplate RequestedCarRating
    public RequestedCarRating getCarRatingById(@PathVariable int id) {
        RequestedCarRating carRating = new RequestedCarRating();
        carRating.setRating(repository.findById(id).get());
        carRating.setCars(restTemplate.getForObject("http://localhost:8081/cars/rating/" + id, List.class));
        return carRating;
    }

    @GetMapping("/mechanic/rating/{id}")
    // method to get rating by id with resttemplate RequestedCarRating
    public RequestedMechanicRating getMechRatingById(@PathVariable int id) {
        RequestedMechanicRating mechRating = new RequestedMechanicRating();
        mechRating.setRating(repository.findById(id).get());
        mechRating.setMechanics(restTemplate.getForObject("http://localhost:8082/mechanic/rating/" + id, List.class));
        return mechRating;
    }

    @GetMapping("/carmech/rating/{id}")
    // method to get rating by id with resttemplate RequestedCarRating
    public CarMech  getCarMechRatingById(@PathVariable int id) {
        CarMech carMech = new CarMech();
        carMech.setCar(restTemplate.getForObject("http://localhost:8081/cars/rating/" + id, List.class));
        carMech.setMech(restTemplate.getForObject("http://localhost:8082/mechanic/rating/" + id, List.class));
        return carMech;
    }

}
