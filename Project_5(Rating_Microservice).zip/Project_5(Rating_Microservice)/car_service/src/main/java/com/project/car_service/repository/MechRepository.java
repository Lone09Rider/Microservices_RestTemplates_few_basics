package com.project.car_service.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.car_service.entity.Mechanic;
import java.util.List;


public interface MechRepository extends JpaRepository<Mechanic, Long> {
    public List<Mechanic> findByRatingId(int ratingId);
} 
    

