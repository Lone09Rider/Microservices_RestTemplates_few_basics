package com.project.car_service.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.car_service.entity.Mechanic;
import com.project.car_service.repository.MechRepository;

@RestController
@RequestMapping("/mechanic")
public class MechanicController {
    @Autowired
    private MechRepository repository;

    // getmapping method to get all the mechanics
    @GetMapping("/all")
    public List<Mechanic> getAllMechanics() {
        return repository.findAll();
    }
    
    // getmapping method to get all mechanics by rating id
    @GetMapping("/rating/{id}")
    public List<Mechanic> getMechanicsByRatingId(@PathVariable int id) {
        return repository.findByRatingId(id);
    }
}
