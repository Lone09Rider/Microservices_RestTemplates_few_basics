package com.project.car.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.car.entity.Car;

public interface CarRepo extends JpaRepository<Car, Integer>{
    public List<Car> findByServiceId(int id);
}
