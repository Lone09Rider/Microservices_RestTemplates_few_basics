package com.project.car.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.car.entity.Car;
import com.project.car.repository.CarRepo;

@RestController
@RequestMapping("/cars")
public class CarController {
    @Autowired
    private CarRepo repo;

    // Get mapping to get all car
    @GetMapping("/all")
    public List<Car> getAllCars() {
        return repo.findAll();
    }

    // Get Mapping method for find by id
    @GetMapping("/{id}")
    public Car getById(@PathVariable int id) {
        return repo.findById(id).get();
    }

    // Postmapping to save a car
    @PostMapping("/save")
    public Car saveCar(@RequestBody Car car) {
        return repo.save(car);
    }

    // Get by findByServiceId
    @GetMapping("/service/{id}")
    public List<Car> getByServiceId(@PathVariable int id) {
        return repo.findByServiceId(id);
    }
}

