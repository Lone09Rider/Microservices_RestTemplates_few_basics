package com.project.services.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.services.entity.Service;

public interface ServiceRepo extends JpaRepository<Service, Integer> {
    
}
