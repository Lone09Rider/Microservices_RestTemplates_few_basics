package com.project.services.model;

import java.util.List;

import com.project.services.entity.Service;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RequestedService {
    private Service service;
    private List<Car> cars;
}
