package com.project.services.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.project.services.entity.Service;
import com.project.services.model.RequestedService;
import com.project.services.repository.ServiceRepo;

@RestController
@RequestMapping("/service")
public class ServiceController {
    @Autowired
    private ServiceRepo repo;

    @Autowired
    private RestTemplate template;

    // getmapping to get all services
    @GetMapping("/all")
    public List<Service> getAllServices() {
        return repo.findAll();
    }

    @GetMapping("/service/{id}")
    public RequestedService getServiceById(@PathVariable int id) {
        RequestedService service = new RequestedService();

        // get service by id
        service.setService(repo.findById(id).get());
        service.setCars(template.getForObject("http://localhost:8081/cars/service/" + id, List.class));

        return service;
    }
}
