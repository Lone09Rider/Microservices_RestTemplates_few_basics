package com.project.services.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Car {
    private int carId;
    private String carName;
    private String carModel;
    private String carColor;
    private int serviceId; // Foreign Key for this microservice
}
