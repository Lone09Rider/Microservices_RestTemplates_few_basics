package com.project.ratingsservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RatingsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
