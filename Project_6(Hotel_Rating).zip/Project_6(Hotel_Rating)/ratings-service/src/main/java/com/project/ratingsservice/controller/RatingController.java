package com.project.ratingsservice.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.project.ratingsservice.entity.Rating;
import com.project.ratingsservice.model.HotelModel;
import com.project.ratingsservice.model.PersonModel;
import com.project.ratingsservice.model.RequestedEntity;
import com.project.ratingsservice.repository.RatingRepository;

@RestController
@RequestMapping("/ratings")
public class RatingController {
    @Autowired
    private RatingRepository ratingRepository;

    @Autowired
    private RestTemplate restTemplate;
    
    @GetMapping("/hotel/{hotelId}")
    public List<RequestedEntity> getRatingsByHotelId(@PathVariable Long hotelId) {
        List<Rating> ratings = ratingRepository.findByHotelId(hotelId);

        List<RequestedEntity> ratingDTOs = ratings
        .stream()
        .map(rating -> {
            HotelModel hotel = restTemplate.getForObject("http://localhost:8081/hotels/" + hotelId, HotelModel.class);
            PersonModel person = restTemplate.getForObject("http://localhost:8082/persons/" + hotelId, PersonModel.class);
            
            RequestedEntity entity = new RequestedEntity();
            entity.setId(rating.getId());
            entity.setHotel(hotel);
            entity.setPerson(person);
            entity.setRating(rating.getRating());
            
            return entity;
        })
        .collect(Collectors.toList());
    
    return ratingDTOs;
    }

    @PostMapping
    public Rating createRating(@RequestBody Rating rating) {
        return ratingRepository.save(rating);
    }
}