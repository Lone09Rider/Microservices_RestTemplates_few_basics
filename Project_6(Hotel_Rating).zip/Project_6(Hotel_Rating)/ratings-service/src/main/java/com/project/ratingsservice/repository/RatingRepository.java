package com.project.ratingsservice.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.project.ratingsservice.entity.Rating;

@Repository
public interface RatingRepository extends JpaRepository<Rating, Long> {
    List<Rating> findByHotelId(Long hotelId);
    List<Rating> findByPersonId(Long personId);
    int findByRating(Long hotelId);
}