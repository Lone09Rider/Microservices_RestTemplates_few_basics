package com.project.ratingsservice.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RequestedEntity {
    private Long id;
    private HotelModel hotel;
    private PersonModel person;
    private int rating;
}
