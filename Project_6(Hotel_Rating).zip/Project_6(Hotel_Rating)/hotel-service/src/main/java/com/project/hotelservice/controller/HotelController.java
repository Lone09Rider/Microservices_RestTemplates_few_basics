package com.project.hotelservice.controller;

import org.springframework.web.bind.annotation.RestController;

import com.project.hotelservice.entity.Hotel;
import com.project.hotelservice.repository.HotelRepository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

@RestController
@RequestMapping("/hotels")
public class HotelController {
    @Autowired
    private HotelRepository hotelRepository;

    @GetMapping
    public List<Hotel> getHotels() {
        return hotelRepository.findAll();
    }
    
    @PostMapping
    public Hotel createHotel(@RequestBody Hotel hotel) {
        return hotelRepository.save(hotel);
    }

    @GetMapping("/{hotelId}")
    public Hotel getHotel(@PathVariable Long hotelId) {
        return hotelRepository.findById(hotelId).get();
    }
}
