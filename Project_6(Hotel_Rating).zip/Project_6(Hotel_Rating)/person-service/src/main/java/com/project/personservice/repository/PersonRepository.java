package com.project.personservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.personservice.entity.Person;

public interface PersonRepository extends JpaRepository<Person, Long> {
    
}
