package com.project.citizen_service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.citizen_service.entity.Citizen;

public interface CitizenRepo extends JpaRepository<Citizen, Integer>{
    public List<Citizen> findByVaccinationCenterId(int id);
}
