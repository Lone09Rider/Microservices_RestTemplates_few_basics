package com.project.citizen_service.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.citizen_service.entity.Citizen;
import com.project.citizen_service.repository.CitizenRepo;

@RestController
@RequestMapping("/citizens")
public class CitizenCotroller {
    @Autowired
    private CitizenRepo repo;

    @GetMapping
    public List<Citizen> getAll() {
        return repo.findAll();
    }

    // getmapping to get citizen by id
    @GetMapping("/{id}")
    public Citizen getById(@PathVariable int id) {
        return repo.findById(id).get();
    }

    // Postmapping to save a citizen
    @PostMapping
    public Citizen save(@RequestBody Citizen citizen) {
        return repo.save(citizen);
    }

    // Find by vaccination center id
    @GetMapping("/vaccinationCenter/{id}")
    public List<Citizen> getByVaccinationCenterId(@PathVariable int id) {
        return repo.findByVaccinationCenterId(id);
    }

    // Delete by id
    @DeleteMapping("/delete/{id}")
    public void deleteById(@PathVariable int id) {
        repo.deleteById(id);
    }
}





