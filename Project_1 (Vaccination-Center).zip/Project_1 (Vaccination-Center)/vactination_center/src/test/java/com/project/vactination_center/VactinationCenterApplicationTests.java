package com.project.vactination_center;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VactinationCenterApplicationTests {

	@Test
	void contextLoads() {
	}

}
