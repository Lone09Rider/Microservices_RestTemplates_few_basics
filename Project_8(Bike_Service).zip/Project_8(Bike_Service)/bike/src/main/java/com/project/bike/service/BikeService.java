package com.project.bike.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.bike.entity.Bike;
import com.project.bike.repository.BikeRepo;
import java.util.List;

@Service
public class BikeService {
    @Autowired
    private BikeRepo repo;

    // Method to getAll Bikes 
    public List<Bike> getAllBikes() {
        return repo.findAll();
    }

    // Method to getOne Bike 
    public Bike getBike(int id) {
        return repo.findById(id).get();
    }

    // Method to add Bike
    public Bike addBike(Bike bike) {
        return repo.save(bike);
    }

    // Method to update Bike
    public Bike updateBike(Bike bike) {
        return repo.save(bike);
    }

    // Method to delete Bike
    public void deleteBike(int id) {
        repo.deleteById(id);
    }

    // Method to findByUserId
    public List<Bike> findByUserId(int userId) {
        return repo.findByUserId(userId);
    }
}
