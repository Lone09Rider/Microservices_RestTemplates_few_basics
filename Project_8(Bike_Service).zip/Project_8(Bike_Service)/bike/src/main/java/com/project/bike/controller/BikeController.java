package com.project.bike.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.bike.entity.Bike;
import com.project.bike.service.BikeService;
import java.util.List;

@RestController
@RequestMapping("/bike")
public class BikeController {
    @Autowired
    private BikeService bikeService;


    // GetMapping to getall bikes 
    @GetMapping("/all")
    public List<Bike> getAllBikes() {
        return bikeService.getAllBikes();
    }

    // GetMapping to get bike by id
    @GetMapping("/{id}")
    public Bike getBikeById(@PathVariable("id") int id) {
        return bikeService.getBike(id);
    }

    // GetMapping to get bike by userId
    @GetMapping("/user/{userId}")
    public List<Bike> getBikeByUserId(@PathVariable("userId") int userId) {
        return bikeService.findByUserId(userId);
    }

    // PostMapping to add bike
    @PostMapping("/add")
    public Bike addBike(Bike bike) {
        return bikeService.addBike(bike);
    }

    // DeleteMapping to Delete a Bike
    @DeleteMapping("/delete/{id}")
    public void deleteBike(@PathVariable("id") int id) {
        bikeService.deleteBike(id);
    }

    // PutMapping to Update a Bike
    @PutMapping("/update")
    public Bike updateBike(Bike bike) {
        return bikeService.updateBike(bike);
    }
}
