package com.project.users.models;

import java.util.List;

import com.project.users.entity.User;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ResponseModel {
    private User user;
    private List<Bike> bikes;
}
