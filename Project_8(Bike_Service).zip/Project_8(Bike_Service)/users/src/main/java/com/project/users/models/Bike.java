package com.project.users.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class Bike {
    private int id;
    private String brand;
    private String model;
    private int userId;
    private String status;
}
