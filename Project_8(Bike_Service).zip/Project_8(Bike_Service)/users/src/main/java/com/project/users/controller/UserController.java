package com.project.users.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.project.users.entity.User;
import com.project.users.models.ResponseModel;
import com.project.users.service.UserService;

@RestController
@RequestMapping("/users")
public class UserController {
    @Autowired
    private UserService userService;
    
    @Autowired
    private RestTemplate restTemplate;

    @GetMapping
    // Method to get all users
    public List<User> getAllUsers() {
        return userService.getAllUsers();
    }

    @GetMapping("/{id}")
    // Method to get user by id
    public User getUserById(@PathVariable int id) {
        return userService.getUserById(id);
    }

    @GetMapping("/bikes/{id}")
    // Method to get all bikes by user id using restTemplate with ResponseModel
    public ResponseModel getBikesByUserId(@PathVariable int id) {
        ResponseModel responseModel = new ResponseModel();
        responseModel.setUser(userService.getUserById(id));
        responseModel.setBikes(restTemplate.getForObject("http://localhost:8081/bike/user/" + id, List.class));
        return responseModel;
    }
}
