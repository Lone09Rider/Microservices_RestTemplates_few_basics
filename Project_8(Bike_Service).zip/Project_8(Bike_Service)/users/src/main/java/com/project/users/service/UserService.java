package com.project.users.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.users.entity.User;
import com.project.users.repository.UserRepository;
import java.util.List;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    // Method to getALl users
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }
    
    // Method to get user by id
    public User getUserById(int id) {
        return userRepository.findById(id).get();
    }
}
