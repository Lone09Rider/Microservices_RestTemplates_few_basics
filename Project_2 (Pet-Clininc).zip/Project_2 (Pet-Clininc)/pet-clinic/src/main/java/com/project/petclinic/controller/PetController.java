package com.project.petclinic.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.petclinic.entity.PetClininc;
import com.project.petclinic.service.PetService;
import java.util.List;

@RestController
@RequestMapping("/pets")
public class PetController {
    @Autowired
    private PetService service;

    // Method to return all pets
    @RequestMapping("/all")
    public List<PetClininc> findAll() {
        return service.findAll();
    }

    // Method to return pet by id
    @RequestMapping("/{id}")
    public PetClininc findById(int id) {
        return service.findById(id);
    }

    // Method to save pet
    @RequestMapping("/save")
    public PetClininc save(@RequestBody PetClininc pet) {
        return service.save(pet);
    }

    // Method to find by vetId
    @GetMapping("/findByVetId/{vetId}")
    public List<PetClininc> findByVetId(@PathVariable int vetId) {
        return service.findByVetId(vetId);
    }
}


