package com.project.petclinic.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.petclinic.entity.PetClininc;
import com.project.petclinic.repository.PetRepo;

@Service
public class PetService {
    @Autowired
    private PetRepo repo;

    // Method to return all pets
    public List<PetClininc> findAll() {
        return repo.findAll();
    }

    // Method to return pet by id
    public PetClininc findById(int id) {
        return repo.findById(id).get();
    }

    // Method to save pet
    public PetClininc save(PetClininc pet) {
        return repo.save(pet);
    }

    // Method to add pet
    public PetClininc add(PetClininc pet) {
        return repo.save(pet);
    }

    // Meyhod to find by vetId
    public List<PetClininc> findByVetId(int vetId) {
        return repo.findByVetId(vetId);
    }

}
