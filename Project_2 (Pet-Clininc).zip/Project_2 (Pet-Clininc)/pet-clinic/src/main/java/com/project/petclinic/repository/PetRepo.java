package com.project.petclinic.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.petclinic.entity.PetClininc;
import java.util.List;

public interface PetRepo extends JpaRepository<PetClininc, Integer> {
    public List<PetClininc> findByVetId(int petId);
}
