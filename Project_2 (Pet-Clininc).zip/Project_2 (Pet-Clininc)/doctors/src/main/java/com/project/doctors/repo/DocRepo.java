package com.project.doctors.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.doctors.entity.Doctor;

public interface DocRepo extends JpaRepository<Doctor, Integer> {
    
}
