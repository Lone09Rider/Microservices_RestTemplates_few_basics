package com.project.doctors.models;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PetClininc {
    private int id;
    private String name;
    private String owner;
    private int vet_id;
}
