package com.project.doctors.models;

import java.util.List;

import com.project.doctors.entity.Doctor;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RequestedEntity {
    private Doctor doctor;
    private List<PetClininc> petClinic;
}
