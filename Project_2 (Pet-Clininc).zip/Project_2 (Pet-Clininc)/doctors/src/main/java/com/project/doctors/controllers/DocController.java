package com.project.doctors.controllers;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.project.doctors.entity.Doctor;
import com.project.doctors.models.RequestedEntity;
import com.project.doctors.repo.DocRepo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import java.util.List;
@RestController
@RequestMapping("/docs")
public class DocController {
    @Autowired
    private DocRepo repo;

    @Autowired
    private RestTemplate restTemplate;

    // To get all docs
    @GetMapping("/all")
    public Object getAllDocs() {
        return repo.findAll();
    }

    @GetMapping("/findByVetId/{id}")
    public RequestedEntity getAllDataBasedOnDocId(@PathVariable int id) {
        RequestedEntity requestedEntity = new RequestedEntity();

        // Get Docs details
        Doctor doc = repo.findById(id).get();
        requestedEntity.setDoctor(doc);

        // get all pets by microservice link
        requestedEntity.setPetClinic(restTemplate.getForObject("http://localhost:8081/pets/findByVetId/" + id, List.class));

        return requestedEntity;
    }
}
