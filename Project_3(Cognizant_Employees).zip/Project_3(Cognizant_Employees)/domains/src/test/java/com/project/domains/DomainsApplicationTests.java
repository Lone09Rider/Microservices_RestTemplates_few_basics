package com.project.domains;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DomainsApplicationTests {

	@Test
	void contextLoads() {
	}

}
