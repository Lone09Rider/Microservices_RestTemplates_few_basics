package com.project.domains.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.project.domains.entity.Domains;
import com.project.domains.models.RequestedModel;
import com.project.domains.repository.DomainRepo;

@RestController
@RequestMapping("/domains")
public class DomainController {
    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private DomainRepo repo;

    // method to get all domains
    @GetMapping("/all")
    public List<Domains> getAllDomains() {
        return repo.findAll();
    }

    @GetMapping("/findbydomainid/{id}")
    public RequestedModel getModel(@PathVariable int id) {
        RequestedModel newModel = new RequestedModel();
        
        Domains domains = repo.findById(id).get();
        newModel.setDomains(domains);

        newModel.setEmps(restTemplate.getForObject("http://localhost:8081/cognizant/findbydomainid/"+id, List.class));
        
        return newModel;
    }

}
