package com.project.domains.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.domains.entity.Domains;

public interface DomainRepo extends JpaRepository<Domains,Integer> {
    
}
