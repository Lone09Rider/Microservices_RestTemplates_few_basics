package com.project.domains.models;

import java.util.List;

import com.project.domains.entity.Domains;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RequestedModel {
    private Domains domains;
    private List<Cognizant> emps;
}
