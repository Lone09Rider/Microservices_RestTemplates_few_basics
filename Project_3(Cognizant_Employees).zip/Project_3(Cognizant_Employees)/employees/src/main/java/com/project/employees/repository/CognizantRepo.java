package com.project.employees.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.employees.entity.Cognizant;

public interface CognizantRepo extends JpaRepository<Cognizant, Integer> {
    public List<Cognizant> findByDomainId(int empId);
}
