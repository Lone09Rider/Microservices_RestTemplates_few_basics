package com.project.employees.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.employees.entity.Cognizant;
import com.project.employees.service.CognizantService;
import java.util.List;

@RestController
@RequestMapping("/cognizant")
public class CognizantController {
    @Autowired
    private CognizantService service;

    // getmapping to find all
    @GetMapping("/all")
    public List<Cognizant> findAll() {
        return service.getAllEmployees();
    }

    // getmapping to find by id
    @GetMapping("/findbyid/{id}")
    public Cognizant getEmployeeById(@PathVariable int id) {
        return service.getEmployeeById(id);
    }

    // postmapping to add cognizant 
    @PostMapping("/add")
    public Cognizant addEmployee(@RequestBody Cognizant cognizant) {
        return service.saveEmployee(cognizant);
    }

    @GetMapping("/findbydomainid/{id}")
    public List<Cognizant> findByDomainId(@PathVariable int id) {
        return service.findByDomainId(id);
    }
}
