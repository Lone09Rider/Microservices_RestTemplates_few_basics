package com.project.employees.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.employees.entity.Cognizant;
import com.project.employees.repository.CognizantRepo;

@Service
public class CognizantService {
    @Autowired
    private CognizantRepo repo;

    // method to save Cognizant
    public Cognizant saveEmployee(Cognizant cognizant) {
        return repo.save(cognizant);
    }

    // method to get Cognizant by id
    public Cognizant getEmployeeById(int id) {
        return repo.findById(id).get();
    }

    // method to find all Cognizants
    public List<Cognizant> getAllEmployees() {
        return repo.findAll();
    }

    // method to findByDomainId
    public List<Cognizant> findByDomainId(int id) {
        return repo.findByDomainId(id);
    }
}
